import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 A class that implements an Observer object that displays a barchart view of
 a data model.
 */
public class Framework extends JFrame implements ActionListener
{
    private BlockMove gamePanel;
    private JPanel startPanel;
    private JButton startButton;
    public Framework() {
        setSize(850, 850);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);

        startPanel = new JPanel();
        startPanel.setBackground(Color.WHITE);
        startPanel.setPreferredSize(new Dimension(800, 800));
        JTextArea textArea = new JTextArea();
        add(textArea);
        String title = "2048";
        textArea.append(title);
        textArea.setEditable(false);
        textArea.setBackground(new Color(0,0,0,0));
        textArea.setOpaque(false);
        // Create a button to start the game
        startButton = new JButton("Start");
        startButton.addActionListener(this);
        gamePanel = new BlockMove();
        gamePanel.setPreferredSize(new Dimension(800, 800));
        //JLabel gameLabel = new JLabel("This is the game panel");
        // gamePanel.add(gameLabel, BorderLayout.NORTH);


        startButton.setOpaque(false);

        startButton.setFocusable(false);

        // Add the components to the frame
        startPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 200));
        startPanel.add(startButton);
        startPanel.add(textArea);
        add(startPanel, BorderLayout.CENTER);
        setVisible(true);


    }
    @Override
    public void actionPerformed(ActionEvent e) {
        // Start the game loop when the start button is clicked
        if(e.getSource() == startButton) {
            getContentPane().removeAll();
            add(gamePanel, BorderLayout.CENTER);
            addKeyListener(gamePanel);
            revalidate();
            repaint();
            requestFocusInWindow();
            startGameLoop();
        }
    }        /*JFrame frame = new JFrame("Move Block");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(250, 250);
    BlockMove panel = new BlockMove();
        panel.addBlock(1,2);
        panel.addBlock(1,3);
        frame.add(panel);*/

    void startGameLoop() {
        gamePanel.addBlock();
        gamePanel.addBlock();
        gamePanel.setVisible(true);
        //   Paintblock newBlock = new Paintblock(1, 0, 0);
        //   frame.add(newBlock);


        // Implement the game loop to update the game state and repaint the game panel
    }
}
