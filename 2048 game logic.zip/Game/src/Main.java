import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {

                Framework panel = new Framework();
                //   Paintblock newBlock = new Paintblock(1, 0, 0);
                //   frame.add(newBlock);

                panel.setVisible(true);




    }
}