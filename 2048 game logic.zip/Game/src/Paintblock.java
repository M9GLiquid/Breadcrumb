import javax.swing.*;
import java.awt.*;

public class Paintblock extends JPanel {
    private int value;
    private int posY;
    private int posX;
/*
    public Paintblock(int value, int posY, int posX){
        this.value = value;
        this.posY = posY;
        this.posX = posX;
    }
@Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Draw the paint block with the specified value

    }



}


 */}