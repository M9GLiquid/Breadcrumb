import javax.swing.*;
import java.awt.*;

public class Images extends JPanel {

    private ImageIcon image;
    public Images(){
        image = new ImageIcon("C:\\Users\\rimab\\Desktop\\Advanced Object Oriented Programming\\Lectures\\Game\\sokoban_icons\\blank.png");

    }
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);

        if(image != null){
            g.drawImage(image.getImage(),0,0,getWidth(),getHeight(),this);

        }
    }
    public void loadImage(String ImageName){

    }
}
