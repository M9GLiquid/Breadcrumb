import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;

public class BlockMove extends JPanel implements KeyListener {
    private int[][] board;
    private int posX;
    private int posY;
    private boolean isPressed = false;

    public BlockMove() {
        setFocusable(true);
        addKeyListener(this);
        board = new int[4][4];
        repaint();
    }

    public void addBlock() {
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                if (this.board[col][row] == 0) {
                    this.setFocusable(true);
                    this.addKeyListener(this);
                    int[] values = {2, 4}; // Generate a random index into the array
                    this.board[col][row] = values[(int) (Math.random() * values.length)];
                    return;
                }

            }
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }


    @Override
    public void keyReleased(KeyEvent e) {


        if (e.getKeyCode() == KeyEvent.VK_UP && !isPressed){
            //upp börjar kolla rad 0 col 0
            for (int row = 0; row < 4; row++) {
                for (int col = 0; col < 4; col++) {
                    if (this.board[col][row] != 0) {
                        int newRow = row;
                        while (newRow > 0 && board[col][newRow - 1] == 0) {
                            newRow--;
                        }
                        if(newRow > 0 && (this.board[col][row] == this.board[col][newRow - 1])) {
                            this.board[col][newRow - 1] = this.board[col][row]*2;
                            posY = newRow - 1;
                            this.board[col][row] = 0;
                        } else if (newRow != row){

                            this.board[col][newRow] = board[col][row];
                            posY = newRow;
                            this.board[col][row] = 0;
                        }

                    }

                }
            }

        }else if (e.getKeyCode() == KeyEvent.VK_DOWN && !isPressed) {
            //newY > 0 needs to be grater than 0 to not move it off board
            //board[posX][newPosY-1] == 0 check if the current pos of the block is empty
            //newposY-- decrease by one to move the block down one row
            //while loop because we want to make sure it has reached the bottom or top of the board
            //So it moves one row at a time and checks each time if it is blocked
            for (int row = 3; row > -1; row--) {
                for (int col = 0; col < 4; col++) {

                    if (board[col][row] != 0) {
                        int newRow = row;


                        while (newRow < 3 && board[col][newRow + 1] == 0) {
                            newRow++;

                        }
                        if (newRow < 3 && (board[col][row] == board[col][newRow + 1])) {
                            board[col][newRow + 1] = board[col][row]*2;
                            posY = newRow + 1;
                            board[col][row] = 0;
                        } else if(newRow != row) {
                            board[col][newRow] = board[col][row];
                            posY = newRow;
                            board[col][row] = 0;
                        }


                    }


                }

            }

        }
        else if (e.getKeyCode() == KeyEvent.VK_LEFT && !isPressed) {
            for (int col = 0; col < 4; col++) {
                for (int row = 0; row < 4; row++) {
                    if (board[col][row] != 0) {
                        int newCol = col;
                        while (newCol > 0 && board[newCol - 1][row] == 0) {
                            newCol--;
                        }
                        if (newCol > 0 && (board[col][row] == board[newCol - 1][row])) {
                            board[newCol-1][row] = board[col][row]*2;
                            posX = newCol - 1;
                            board[col][row] = 0;
                        } else if (newCol != col){
                            board[newCol][row] = board[col][row];
                            posX = newCol;
                            board[col][row] = 0;
                        }



                    }

                }
            }

        }
        else if (e.getKeyCode() == KeyEvent.VK_RIGHT && !isPressed) {
            for (int col = 3; col > -1; col--) {
                //right är col-- byt plats right o left
                for (int row = 0; row < 4; row++) {
                    if (board[col][row] != 0) {
                        int newCol = col;
                        while (newCol < 3 && board[newCol + 1][row] == 0) {
                            newCol++;
                        }
                        if (newCol < 3 && (board[col][row] == board[newCol + 1][row])) {
                            board[newCol + 1][row] = board[col][row]*2;
                            posX = newCol + 1;
                            board[col][row] = 0;
                        } else if (newCol != col) {
                            board[newCol][row] = board[col][row];
                            posX = newCol;
                            board[col][row] = 0;
                        }

                    }
                }

            }

        }
        if(!isPressed){
            addBlock();
        }
        isPressed = true;

        repaint();

    }


    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        if (keyCode == KeyEvent.VK_UP || keyCode == KeyEvent.VK_DOWN ||keyCode == KeyEvent.VK_RIGHT|| keyCode == KeyEvent.VK_LEFT) {
            isPressed = false;
        }
    }
   /* public void winorLoss(){
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                if(board)
            }

    }*/

    @Override
    public void paintComponent(Graphics g) {
        // Paint the game board with the blocks
        super.paintComponent(g);
        Color color = null;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (board[i][j] != 0) {
                    if (board[i][j] == 2) {
                        color = new Color(238,232,170, 100);
                    }
                    else if(board[i][j] == 4) {
                        color = new Color(255,215,0, 100);
                    }
                    else if(board[i][j] == 8) {
                        color = new Color(218,165,32, 100);
                    }
                    else if(board[i][j] == 16) {
                        color = new Color(255,165,0, 100);
                    }
                    else if(board[i][j] == 32) {
                        color = new Color(255,140,0, 100);
                    }
                    g.setColor(color);
                    g.fillRect(i * 200, j * 200, 200, 200);
                    g.setColor(Color.WHITE);
                    g.setFont(new Font("Arial", Font.BOLD, 40));
                    g.drawString(Integer.toString(board[i][j]), ((i * 200) + 100), (j * 200) + 100);
                    g.drawRect(i * 200, j * 200, 200, 200);
                }
            }
        }

    }
}
